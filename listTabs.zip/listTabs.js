// ==UserScript==
// @name                 List Tabs
// @version              1.0
// @description          Generates a numbered list of tabs by name
// ==/UserScript==

(function() { 

  "use strict";

  var {classes: Cc, interfaces: Ci, utils: Cu} = Components;

  const btnImage = "list-style-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAC6UlEQVR42u2VS2gTURiFz+TRxpnUaKiglba2kXZXsNS6deUmtVjpQ5cqiHGjK0EQF1IsuKvgRlA3gtCgBSWgCCoYFNtKFwpSofaFtInNpHnMJM1rvDPpxKTTpHeSVDeezSWX//7nu/+cyTDIEzssjZFlAPRyizeYQR31GjH55vu51MCKYKI+TOpB6iuCyAeQym1CAOQ+8uTGKMplWLcGgEhaWFzSbd7c1Kg2HSDnt318pN69AeCuKgA5S3P7/DPMf4B8ACVAfxlACaMMoKZfV5O8ZnIj3edUKQDl3LyUJo91K+vRTxPbTqLqAKq5qlIQVQeYn5vFrzNnNfvFIKoKIJurooUoAHj08IGyee78BWVVf9Oo39mBgGgv2KOBKAkw92MWNKrneDhWTiO5bsD0vjdFIbadQDmK+CbRzvcjFgK4PeRtTkrwWt9pIHYkA7L54dUhrEdSYG0MDOkMolEGrNWED9zrXN2hFkfRHmUDaMwlYh6Wzc2IiwkIYQtmHC9LmmsAaEMoB84RciHB+2GxGmAwShBDEqy7JcRjBC5ogb/pDp55+VyvsgC2CqESOGKeDPpQyxlhMqSzN7dlPykyyFLLU6wK2TeipVXHBGjG3izehuSfKjBXb55KMliwj8LW1kf9KKkBhPAKGgMuZHyflbFvNlfHrsecGmAtsIjW8BWNOcuakUgmyjbXAGwVwsF+J2xBMlb/Y5h3GWE2phEJ/TGPBhn4mkaVwG2likN4oGYCB5evZc1NxHyNAWcxIYEUBF7Cav1V+KynihpUFEIZoCtwXDHn657n9veGTkIIZhDmemHouqd77NQAi7Pf0R07UWBuj/RCDKYhGjshdD5BrYXdOYC5b1/Qzkp48daLizdHsPzeA/anE0KiAXzHOOrsDRWZawA2Z2D+6zRmpj4q5vdvXcdQ2wgi6SMItA5j/NUklUFFIfR4PLjsugRnTw/uuvoQq+EQZ+2IJmuob1jVf8KdUA7gn7hv6DeopcoYcRFYOgAAAABJRU5ErkJggg==')",
        btnLabel = "List Tabs",
        btnTip = "Generate a numbered list of tabs by name",
        fileName = "Tab List",
        generated  = "Tabs Generated On",
        insertTimestamp = true,
        fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream),
        fp = Cc["@mozilla.org/filepicker;1"].createInstance(Ci.nsIFilePicker);

  function timestamp() {
    let date = new Date(), wkdy = date.getDay(), mth = date.getMonth(), dy = date.getDate(),
        Weekday = "Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday",
        Month = "January,February,March,April,May,June,July,August,September,October,November,December",
        Day = "'',1st,2nd,3rd,4th,5th,6th,7th,8th,9th,10th,11th,12th,13th,14th,15th,16th,17th,18th,19th,20th,21st,22nd,23rd,24th,25th,26th,27th,28th,29th,30th,31st",
        AM = "AM", PM = "PM",
        weekdays = Weekday.split(","), months = Month.split(","), days = Day.split(","),
        weekday = weekdays[wkdy] + ", ", month = months[mth] + " ", day = days[dy] + ", ", year = date.getFullYear(),
        hour = date.getHours(), minute = date.getMinutes(), second = date.getSeconds(), timeday;
    if (hour < 12) { timeday = " " + AM } else { timeday = " " + PM }
    if (hour > 12) { hour = hour - 12 }
    if (hour === 0) { hour = 12 }
    if (minute < 10) { minute = ":0" + minute } else { minute = ":" + minute }
    if (second < 10) { second = ":0" + second } else { second = ":" + second }
    return weekday + month + day + year + " " + hour + minute + second + timeday;
  }

  function listTabs(e) {
    if (e.button === 0) {
      let list = [], indent, out, str, tabs = gBrowser.tabContainer.childNodes;
      if (tabs.length < 10) {
        for (let i = 0; i < tabs.length; i++) list.push("(" + (i+1) + ") " + tabs[i].label);
      } else if (tabs.length > 9 && tabs.length < 99) {
        for (let i = 0; i < tabs.length; i++) {
          let lab = tabs[i].label;
          if (i < 9) indent = " (";
          else if (i > 8 && i < 99) indent = "(";
          list.push(indent + (i+1) + ") " + lab);
        }
      } else {
        for (let i = 0; i < tabs.length; i++) {
          let lab = tabs[i].label;
          if (i < 9) indent = "  (";
          else if (i > 8 && i < 99) indent = " (";
          else indent = "(";
          list.push(indent + (i+1) + ") " + lab);
      } }
      insertTimestamp ? str = tabs.length + " " + generated + " " + timestamp() + "\n\n" : str = "";
      out = str + list.toString().replace(/,/g, "\n");
      fp.init(window, "Save", fp.modeSave);
      fp.defaultString = fileName;
      fp.defaultExtension = "txt"; 
      fp.appendFilters(fp.filterText);
      fp.open(function (evt) {
        if (evt == fp.returnOK || evt == fp.returnReplace) {
          if (fp.file.exists()) fp.file.remove(true);
          fp.file.create(Ci.nsIFile.NORMAL_FILE_TYPE, 420);
          fos.init(fp.file, 0x02, 0x200, false); 
          fos.write(out, out.length); 
          fos.close();
        }
      });
  } }

  try {
    CustomizableUI.createWidget({
      id: "list-tabs",
      type: "custom",
      onBuild: function(aDoc) {
        let btn = aDoc.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "toolbarbutton");
        btn.onclick = event => listTabs(event);
        var props = {
          id: "list-tabs",
          class: "toolbarbutton-1 chromeclass-toolbar-additional",
          label: btnLabel,
          style: btnImage,
          tooltiptext: btnTip
        };
        for (let p in props) btn.setAttribute(p, props[p]);
        return btn;
      }
    });
  } catch(e) {};

})();

